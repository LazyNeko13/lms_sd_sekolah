HTTP Factories
==============

This repository holds all interfaces related to [PSR-17 (HTTP Message Factories)][psr-17]. 
Please refer to the specification for a description.

You can find implementations of the specification by looking for packages providing the 
[psr/http-factory-implementation](https://packagist.org/providers/psr/http-factory-implementation) virtual package.

[psr-17]: https://www.php-fig.org/psr/psr-17/
